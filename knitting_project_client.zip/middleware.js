import { NextResponse } from 'next/server';
import react from 'react';

const middleware = (req) => {

    let verify = req.cookies.get("jwt")
    console.log(req.cookies,'req')
    console.log(verify)
    let url = req.url
    if (!verify && url.includes("/dashboard")) {
        return NextResponse.redirect("http://localhost:3000/login")
    }

};
export default middleware;