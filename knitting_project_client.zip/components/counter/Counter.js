"use client"
// components/Counter.js
import React from "react";

export default function Counter() {
//   const count = useSelector((state) => state.counter);
//   const dispatch = useDispatch();
  return (
    <div>
      <button >Increment</button>
      <span>1</span>
    </div>
  );
}