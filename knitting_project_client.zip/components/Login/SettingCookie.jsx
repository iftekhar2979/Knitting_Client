import react from 'react';

const SettingCookie = (props) => {
    return 
};
export default SettingCookie;