"use client"

const SingleOrder = (props) => {
    return (
        <div>this is single Order</div>
    )
};
export default SingleOrder;