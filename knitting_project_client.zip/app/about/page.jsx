import About from "@/components/About/About";


export default function about() {
  return (
    <>
    <About/>
    </>
  )
}
