import Login from "@/components/Login/Login";
const page = (props) => {

  return (
    <Login />
  )
};
export default page;