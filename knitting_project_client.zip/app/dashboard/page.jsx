// import Counter from "@/components/counter/counter";



const dashboard = (props) => {

    return (
        <div>
            
        </div>

    )
};
export default dashboard;