
import PIList from '@/components/dashboard/perfromaInvoices/PIList';

const page = (props) => {
    return (
        <div>
           <PIList/>
        </div>
    )
};
export default page;