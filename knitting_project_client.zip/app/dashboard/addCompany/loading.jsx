import Loading from '@/components/utils/Loading';
import react from 'react';

const loading = (props) => {
    return <Loading/>
};
export default loading;