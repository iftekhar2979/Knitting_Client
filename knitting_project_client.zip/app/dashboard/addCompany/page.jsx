import { AddCompany } from "@/components/dashboard/company/AddCompany";
const addCompany = () => {
  return (
    <main className="mx-6">
      <AddCompany></AddCompany>
    </main>
  )
}
export default addCompany
