import react from 'react';

const page = (props) => {
    return (
        <div>
            This is Proforma Invoice
        </div>
    )
};
export default page;