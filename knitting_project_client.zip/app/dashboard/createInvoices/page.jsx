import CreateInvoice from '@/components/dashboard/createInvoice/CreateInvoice';
import react from 'react';

const page = (props) => {
    return (
        <CreateInvoice/>
    )
};
export default page;